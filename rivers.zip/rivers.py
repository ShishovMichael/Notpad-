from kanren import run, fact, eq, Relation, var
adjacent = Relation()
coastal = Relation()
#Определим входные файлы, из которых будем загружать данные
file_coastal = 'rivers_list.txt'
file_adjacent = 'rivers_ad.txt'

# Чтение файла, содержащего данные о прибрежных штатах
# Read the file containing the coastal states
with open(file_coastal, 'r') as f:
    line = f.read()
    coastal_states = line.split(',')

#	Добавление данных в базу фактов
# Add the info to the fact base
for state in coastal_states:
    fact(coastal, state)

#	Чтение файла, содержащего данные о смежности рек
# Read the file containing the coastal states
with open(file_adjacent, 'r') as f:
    adjlist = [line.strip().split(',') for line in f if line and line[0].isalpha()]

#	Добавление информации в базу данных
# Add the info to the fact base
for L in adjlist:
    head, tail = L[0], L[1:]
    for state in tail:
        fact(adjacent, head, state)

#	Инициализация переменных
# Initialize the variables
x = var()
y = var()

#	Проверка того, соседствует ли Волга  с Анадырем
# Is Volga adjacent to Anadyr?
output = run(0, x, adjacent('Волга', 'Анадырь'))
print('\nСоседствует ли Волга  с Анадырем?:')
print('Да' if len(output) else 'Нет')


#	Реки, соседствующие с рекой Волга
# States adjacent to Volga
output = run(0, x, adjacent('Волга', x))
print('\nРеки соседствующие со рекой Волга:')
for item in output:
    print(item)

output = run(0,x,adjacent("Дон" , x))
print('\n Реки соседствующие с Доном ')
for item in output:
    print(item)    



#	Реки , которые соседствуют с Волгой и являются прибрежными
# States adjacent to Volga  that are coastal
output = run(0, x, adjacent("Волга", x), coastal(x))
print('\nРеки, которые соседствуют с Волгой :')
for item in output:
    print(item)


#	Вывод списка 'и' рек, граничащих с прибрежной рекой
# List of 'n' states that border a coastal state
n = 7
output = run(n, x, coastal(y), adjacent(x, y))
print('\nСписок из ' + str(n) + ' рек , граничающих с рекам:')
for item in output:
    print(item)

#	Список рек, соседствующих в двумя заданными  реками
# List of states that adjacent to the two given states
output = run(0, x, adjacent('Москва', x), adjacent('Дон', x))
print('\Реки , соседствующих с Москвой  и  Доном:')
for item in output:
    print(item)
    
output = run(0,x,adjacent ('Дон', x), adjacent('Волга',x))
for item in output:
    print(item)

output = run(0,x,adjacent('Дон',x), adjacent('Буй',x))
for item in output:
    print(item)
     